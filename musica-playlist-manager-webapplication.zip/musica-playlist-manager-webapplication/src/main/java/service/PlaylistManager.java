package service;

import dsa.CircularLinkedList;
import model.Song;
import java.util.ArrayList;
import java.util.Random;

public class PlaylistManager {
    public CircularLinkedList playlist;
    public ArrayList<Song> shuffleList; //de sau nay dung chuc nang shuffle nha may con ga

    public PlaylistManager() {
        playlist = new CircularLinkedList();
        shuffleList = new ArrayList<>();
    }

    public void addSong(Song song) {
        playlist.addLast(song);
        Song newSong = playlist.addLast(song);
        shuffleList.add(newSong);
    }

    public void removeSong(String songId) {
        playlist.remove(songId);
    }

    public boolean isEmpty() {
        return playlist.isEmpty();
    }
    public void shufflePlaylist(){
        if(shuffleList == null || shuffleList.isEmpty()){
            return;
        }
        Random random = new Random();
        int n = shuffleList.size();
        
        //Fisher-Yates
        for(int i = n - 1 ; i > 0; i--){
            int j = random.nextInt(i + 1);
            
            Song temp = shuffleList.get(i);
            shuffleList.set(i, shuffleList.get(j));
            shuffleList.set(j, temp);
        }
    }
}
